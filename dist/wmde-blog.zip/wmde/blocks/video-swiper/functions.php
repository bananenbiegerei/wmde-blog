<?php

wp_enqueue_script('plyr', get_stylesheet_directory_uri() . '/'. WMDE_BB_BLOCKS_DIR . '/video-swiper/plyr.js', []);
