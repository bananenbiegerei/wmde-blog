<?php get_header(); ?>

<div class="container">
    <?php get_template_part("template-parts/style-tile/spaces"); ?>
    <?php get_template_part("template-parts/style-tile/typography"); ?>
    <?php get_template_part("template-parts/style-tile/buttons"); ?>
    <?php get_template_part("template-parts/style-tile/forms"); ?>
</div>

<?php get_footer(); ?>