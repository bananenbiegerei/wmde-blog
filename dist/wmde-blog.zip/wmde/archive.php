<?php get_header();?>
	archive
<?php get_footer(); ?>
