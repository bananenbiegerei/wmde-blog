<header aria-hidden="true" id="titlebar_desktop" class="border-b border-gray-200 hidden md:block nohover:hidden">
	<div class="bg-white container items-center py-3 mx-4 flex">
		<?php get_template_part('template-parts/header-top/titlebar_content'); ?>
	</div>
</header>
