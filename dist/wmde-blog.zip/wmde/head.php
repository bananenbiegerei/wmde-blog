<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width">
	<?php wp_head(); ?>
	<script>
			// Contains all swipers to be initialized by 'site.js'
			var SwipersConfig = {
				// "swiperID" : { swiperOptions... }
			};
	</script>

</head>
